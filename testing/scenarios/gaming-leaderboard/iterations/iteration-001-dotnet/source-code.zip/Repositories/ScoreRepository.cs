using Microsoft.Azure.Cosmos;
using GamingLeaderboard.Models;
using GamingLeaderboard.Services;

namespace GamingLeaderboard.Repositories;

/// <summary>
/// Repository for score operations.
/// Container: scores, Partition Key: /playerId
/// 
/// Rule 3.1: Player score queries are single-partition.
/// Rule 3.5: Parameterized queries throughout.
/// Rule 4.1: Async APIs.
/// </summary>
public class ScoreRepository
{
    private readonly CosmosDbService _cosmosDb;
    private readonly ILogger<ScoreRepository> _logger;

    public ScoreRepository(CosmosDbService cosmosDb, ILogger<ScoreRepository> logger)
    {
        _cosmosDb = cosmosDb;
        _logger = logger;
    }

    /// <summary>
    /// Submit a new score. Creates a new score document in the scores container.
    /// </summary>
    public async Task<Score> SubmitScoreAsync(Score score)
    {
        var response = await _cosmosDb.ScoresContainer.CreateItemAsync(
            score,
            new PartitionKey(score.PlayerId));

        _logger.LogDebug("SubmitScore for {PlayerId}: {RU} RU, Score: {Score}",
            score.PlayerId, response.RequestCharge, score.Value);

        return response.Resource;
    }

    /// <summary>
    /// Get a player's recent scores. Single-partition query.
    /// Rule 3.6: Project only needed fields.
    /// Rule 3.4: Use continuation tokens for pagination.
    /// </summary>
    public async Task<List<Score>> GetPlayerScoresAsync(string playerId, int limit = 20)
    {
        // Rule 3.5: Parameterized query
        var query = new QueryDefinition(
            "SELECT c.id, c.playerId, c.score, c.country, c.weekId, c.submittedAt " +
            "FROM c WHERE c.type = @type ORDER BY c.submittedAt DESC OFFSET 0 LIMIT @limit")
            .WithParameter("@type", "score")
            .WithParameter("@limit", limit);

        var options = new QueryRequestOptions
        {
            // Rule 3.1: Single-partition query
            PartitionKey = new PartitionKey(playerId)
        };

        var results = new List<Score>();
        double totalRU = 0;

        using var iterator = _cosmosDb.ScoresContainer.GetItemQueryIterator<Score>(query, requestOptions: options);
        while (iterator.HasMoreResults)
        {
            var response = await iterator.ReadNextAsync();
            results.AddRange(response);
            totalRU += response.RequestCharge;
        }

        _logger.LogDebug("GetPlayerScores {PlayerId}: {Count} results, {RU} total RU",
            playerId, results.Count, totalRU);

        return results;
    }
}
