using System.Net;
using Microsoft.Azure.Cosmos;
using GamingLeaderboard.Models;
using GamingLeaderboard.Services;

namespace GamingLeaderboard.Repositories;

/// <summary>
/// Repository for player CRUD operations.
/// Container: players, Partition Key: /playerId
/// 
/// Rule 3.1: All queries are single-partition (by playerId).
/// Rule 3.5: Parameterized queries throughout.
/// Rule 4.1: Async APIs throughout.
/// Rule 8.4: Track RU consumption for all operations.
/// </summary>
public class PlayerRepository
{
    private readonly CosmosDbService _cosmosDb;
    private readonly ILogger<PlayerRepository> _logger;

    public PlayerRepository(CosmosDbService cosmosDb, ILogger<PlayerRepository> logger)
    {
        _cosmosDb = cosmosDb;
        _logger = logger;
    }

    /// <summary>
    /// Get a player by their ID. Point read — most efficient operation (1 RU for 1KB).
    /// </summary>
    public async Task<Player?> GetPlayerAsync(string playerId)
    {
        try
        {
            var response = await _cosmosDb.PlayersContainer.ReadItemAsync<Player>(
                playerId,
                new PartitionKey(playerId));

            _logger.LogDebug("GetPlayer {PlayerId}: {RU} RU", playerId, response.RequestCharge);
            return response.Resource;
        }
        catch (CosmosException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
        {
            _logger.LogDebug("Player {PlayerId} not found", playerId);
            return null;
        }
    }

    /// <summary>
    /// Create or update a player profile.
    /// Uses upsert for idempotent create-or-update semantics.
    /// </summary>
    public async Task<Player> UpsertPlayerAsync(Player player)
    {
        var response = await _cosmosDb.PlayersContainer.UpsertItemAsync(
            player,
            new PartitionKey(player.PlayerId));

        _logger.LogDebug("UpsertPlayer {PlayerId}: {RU} RU", player.PlayerId, response.RequestCharge);
        return response.Resource;
    }

    /// <summary>
    /// Update player stats after a new score submission.
    /// Uses optimistic concurrency with ETag to prevent lost updates.
    /// </summary>
    public async Task<Player> UpdatePlayerStatsAsync(string playerId, long newScore)
    {
        // Get or create the player — point read
        var player = await GetPlayerAsync(playerId);

        if (player == null)
        {
            throw new InvalidOperationException($"Player {playerId} not found. Create the player first via score submission.");
        }

        // Update cumulative stats (denormalized — Rule 1.2)
        player.TotalGamesPlayed++;
        player.TotalScore += newScore;
        player.AverageScore = (double)player.TotalScore / player.TotalGamesPlayed;
        player.LastPlayedAt = DateTime.UtcNow;

        if (newScore > player.BestScore)
        {
            player.BestScore = newScore;
        }

        var response = await _cosmosDb.PlayersContainer.UpsertItemAsync(
            player,
            new PartitionKey(player.PlayerId));

        _logger.LogDebug("UpdatePlayerStats {PlayerId}: {RU} RU, Games: {Games}, Best: {Best}",
            playerId, response.RequestCharge, player.TotalGamesPlayed, player.BestScore);

        return response.Resource;
    }
}
