using Microsoft.Azure.Cosmos;
using GamingLeaderboard.Models;
using GamingLeaderboard.Helpers;
using GamingLeaderboard.Services;

namespace GamingLeaderboard.Repositories;

/// <summary>
/// Repository for leaderboard operations.
/// Container: leaderboards, Partition Key: /leaderboardKey
/// 
/// This is the MATERIALIZED VIEW container (Rule 9.1).
/// Instead of running expensive cross-partition ORDER BY queries on the scores
/// container, we maintain denormalized leaderboard entries here.
/// 
/// Each leaderboard (e.g., "global_2026-W07", "US_2026-W07") is a separate
/// partition, enabling efficient single-partition "Top N" queries.
/// 
/// Rule 5.1: Composite index on (bestScore DESC, lastUpdatedAt ASC).
/// Rule 3.1: All queries are single-partition.
/// Rule 3.5: Parameterized queries.
/// Rule 3.6: Project only needed fields.
/// </summary>
public class LeaderboardRepository
{
    private readonly CosmosDbService _cosmosDb;
    private readonly ILogger<LeaderboardRepository> _logger;

    public LeaderboardRepository(CosmosDbService cosmosDb, ILogger<LeaderboardRepository> logger)
    {
        _cosmosDb = cosmosDb;
        _logger = logger;
    }

    /// <summary>
    /// Update leaderboard entries when a new score is submitted.
    /// Updates both weekly and all-time leaderboards for both global and regional.
    /// 
    /// In production, this would be done via Change Feed processor (Rule 9.1).
    /// For the emulator/local dev, we update inline for simplicity.
    /// </summary>
    public async Task UpdateLeaderboardsAsync(Player player, long newScore, string weekId)
    {
        var leaderboardKeys = new[]
        {
            LeaderboardKeyHelper.GlobalWeekly(weekId),
            LeaderboardKeyHelper.RegionalWeekly(player.Country, weekId),
            LeaderboardKeyHelper.GlobalAllTime(),
            LeaderboardKeyHelper.RegionalAllTime(player.Country)
        };

        foreach (var leaderboardKey in leaderboardKeys)
        {
            await UpsertLeaderboardEntryAsync(player, leaderboardKey);
        }
    }

    /// <summary>
    /// Upsert a leaderboard entry for a player in a specific leaderboard.
    /// Uses upsert for idempotent behavior — if the player already has an entry
    /// in this leaderboard, it's updated; otherwise created.
    /// </summary>
    private async Task UpsertLeaderboardEntryAsync(Player player, string leaderboardKey)
    {
        var entry = new LeaderboardEntry
        {
            Id = player.PlayerId, // One entry per player per leaderboard
            LeaderboardKey = leaderboardKey,
            PlayerId = player.PlayerId,
            DisplayName = player.DisplayName,
            Country = player.Country,
            BestScore = player.BestScore,
            TotalGamesPlayed = player.TotalGamesPlayed,
            LastUpdatedAt = DateTime.UtcNow
        };

        var response = await _cosmosDb.LeaderboardsContainer.UpsertItemAsync(
            entry,
            new PartitionKey(leaderboardKey));

        _logger.LogDebug("UpsertLeaderboardEntry {LeaderboardKey}/{PlayerId}: {RU} RU",
            leaderboardKey, player.PlayerId, response.RequestCharge);
    }

    /// <summary>
    /// Get the top N players for a leaderboard.
    /// Single-partition query on the leaderboards container — fast and cheap.
    /// 
    /// Rule 3.1: Single-partition query (leaderboardKey is partition key).
    /// Rule 5.1: Uses composite index (bestScore DESC, lastUpdatedAt ASC).
    /// </summary>
    public async Task<LeaderboardResponse> GetTopPlayersAsync(string leaderboardKey, int top = 100)
    {
        // Rule 3.5: Parameterized query
        var query = new QueryDefinition(
            "SELECT c.playerId, c.displayName, c.country, c.bestScore, c.totalGamesPlayed " +
            "FROM c WHERE c.type = @type " +
            "ORDER BY c.bestScore DESC, c.lastUpdatedAt ASC " +
            "OFFSET 0 LIMIT @top")
            .WithParameter("@type", "leaderboardEntry")
            .WithParameter("@top", top);

        var options = new QueryRequestOptions
        {
            PartitionKey = new PartitionKey(leaderboardKey)
        };

        var entries = new List<LeaderboardEntryDto>();
        double totalRU = 0;
        int rank = 1;

        using var iterator = _cosmosDb.LeaderboardsContainer.GetItemQueryIterator<LeaderboardEntry>(
            query, requestOptions: options);

        while (iterator.HasMoreResults)
        {
            var response = await iterator.ReadNextAsync();
            totalRU += response.RequestCharge;

            foreach (var entry in response)
            {
                entries.Add(new LeaderboardEntryDto
                {
                    Rank = rank++,
                    PlayerId = entry.PlayerId,
                    DisplayName = entry.DisplayName,
                    Country = entry.Country,
                    BestScore = entry.BestScore,
                    TotalGamesPlayed = entry.TotalGamesPlayed
                });
            }
        }

        _logger.LogInformation("GetTopPlayers {LeaderboardKey}: {Count} entries, {RU} total RU",
            leaderboardKey, entries.Count, totalRU);

        return new LeaderboardResponse
        {
            LeaderboardKey = leaderboardKey,
            Entries = entries,
            TotalEntries = entries.Count
        };
    }

    /// <summary>
    /// Get a player's rank and the players ±10 positions around them.
    /// 
    /// Strategy: Query all entries in the leaderboard partition sorted by score,
    /// find the player, then return surrounding entries.
    /// 
    /// For large leaderboards, a more efficient approach would be to maintain
    /// a rank cache, but for the ~500K scale this is acceptable since the
    /// leaderboard partition contains at most ~500K entries.
    /// 
    /// Rule 3.1: Single-partition query.
    /// </summary>
    public async Task<PlayerRankResponse?> GetPlayerRankAsync(string playerId, string leaderboardKey)
    {
        // Rule 3.5: Parameterized query  
        // Rule 3.6: Project only needed fields
        var query = new QueryDefinition(
            "SELECT c.playerId, c.displayName, c.country, c.bestScore, c.totalGamesPlayed " +
            "FROM c WHERE c.type = @type " +
            "ORDER BY c.bestScore DESC, c.lastUpdatedAt ASC")
            .WithParameter("@type", "leaderboardEntry");

        var options = new QueryRequestOptions
        {
            PartitionKey = new PartitionKey(leaderboardKey)
        };

        var allEntries = new List<LeaderboardEntryDto>();
        double totalRU = 0;
        int rank = 1;

        using var iterator = _cosmosDb.LeaderboardsContainer.GetItemQueryIterator<LeaderboardEntry>(
            query, requestOptions: options);

        while (iterator.HasMoreResults)
        {
            var response = await iterator.ReadNextAsync();
            totalRU += response.RequestCharge;

            foreach (var entry in response)
            {
                allEntries.Add(new LeaderboardEntryDto
                {
                    Rank = rank++,
                    PlayerId = entry.PlayerId,
                    DisplayName = entry.DisplayName,
                    Country = entry.Country,
                    BestScore = entry.BestScore,
                    TotalGamesPlayed = entry.TotalGamesPlayed
                });
            }
        }

        _logger.LogDebug("GetPlayerRank scan {LeaderboardKey}: {Count} entries, {RU} total RU",
            leaderboardKey, allEntries.Count, totalRU);

        // Find the player in the ranked list
        var playerIndex = allEntries.FindIndex(e => e.PlayerId == playerId);
        if (playerIndex < 0)
        {
            return null; // Player not found in this leaderboard
        }

        var playerEntry = allEntries[playerIndex];

        // Get ±10 surrounding players
        int startIndex = Math.Max(0, playerIndex - 10);
        int endIndex = Math.Min(allEntries.Count - 1, playerIndex + 10);

        var nearbyPlayers = allEntries
            .Skip(startIndex)
            .Take(endIndex - startIndex + 1)
            .ToList();

        return new PlayerRankResponse
        {
            Player = playerEntry,
            NearbyPlayers = nearbyPlayers,
            LeaderboardKey = leaderboardKey
        };
    }
}
