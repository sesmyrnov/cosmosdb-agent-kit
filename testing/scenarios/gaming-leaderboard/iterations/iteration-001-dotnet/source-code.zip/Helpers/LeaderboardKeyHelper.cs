using System.Globalization;

namespace GamingLeaderboard.Helpers;

/// <summary>
/// Helper methods for leaderboard key generation.
/// </summary>
public static class LeaderboardKeyHelper
{
    /// <summary>
    /// Get the ISO 8601 week ID for a given date (e.g., "2026-W07").
    /// </summary>
    public static string GetWeekId(DateTime date)
    {
        var cal = CultureInfo.InvariantCulture.Calendar;
        var week = cal.GetWeekOfYear(date, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
        return $"{date.Year}-W{week:D2}";
    }

    /// <summary>
    /// Get the current week ID.
    /// </summary>
    public static string GetCurrentWeekId() => GetWeekId(DateTime.UtcNow);

    /// <summary>
    /// Build a global leaderboard key for a given week.
    /// e.g., "global_2026-W07"
    /// </summary>
    public static string GlobalWeekly(string weekId) => $"global_{weekId}";

    /// <summary>
    /// Build a regional leaderboard key for a given country and week.
    /// e.g., "US_2026-W07"
    /// </summary>
    public static string RegionalWeekly(string country, string weekId) => $"{country}_{weekId}";

    /// <summary>
    /// Build an all-time global leaderboard key.
    /// </summary>
    public static string GlobalAllTime() => "global_all-time";

    /// <summary>
    /// Build an all-time regional leaderboard key.
    /// </summary>
    public static string RegionalAllTime(string country) => $"{country}_all-time";
}
