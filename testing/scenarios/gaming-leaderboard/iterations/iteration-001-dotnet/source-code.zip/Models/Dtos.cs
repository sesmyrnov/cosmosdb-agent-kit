using System.Text.Json.Serialization;

namespace GamingLeaderboard.Models;

/// <summary>
/// DTOs for API requests and responses.
/// </summary>
/// 
public class SubmitScoreRequest
{
    [JsonPropertyName("playerId")]
    public string PlayerId { get; set; } = default!;

    [JsonPropertyName("displayName")]
    public string DisplayName { get; set; } = default!;

    [JsonPropertyName("country")]
    public string Country { get; set; } = default!;

    [JsonPropertyName("score")]
    public long Score { get; set; }
}

public class LeaderboardResponse
{
    [JsonPropertyName("leaderboardKey")]
    public string LeaderboardKey { get; set; } = default!;

    [JsonPropertyName("entries")]
    public List<LeaderboardEntryDto> Entries { get; set; } = new();

    [JsonPropertyName("totalEntries")]
    public int TotalEntries { get; set; }
}

public class LeaderboardEntryDto
{
    [JsonPropertyName("rank")]
    public int Rank { get; set; }

    [JsonPropertyName("playerId")]
    public string PlayerId { get; set; } = default!;

    [JsonPropertyName("displayName")]
    public string DisplayName { get; set; } = default!;

    [JsonPropertyName("country")]
    public string Country { get; set; } = default!;

    [JsonPropertyName("bestScore")]
    public long BestScore { get; set; }

    [JsonPropertyName("totalGamesPlayed")]
    public int TotalGamesPlayed { get; set; }
}

public class PlayerRankResponse
{
    [JsonPropertyName("player")]
    public LeaderboardEntryDto Player { get; set; } = default!;

    [JsonPropertyName("nearbyPlayers")]
    public List<LeaderboardEntryDto> NearbyPlayers { get; set; } = new();

    [JsonPropertyName("leaderboardKey")]
    public string LeaderboardKey { get; set; } = default!;
}

public class PlayerProfileResponse
{
    [JsonPropertyName("playerId")]
    public string PlayerId { get; set; } = default!;

    [JsonPropertyName("displayName")]
    public string DisplayName { get; set; } = default!;

    [JsonPropertyName("country")]
    public string Country { get; set; } = default!;

    [JsonPropertyName("totalGamesPlayed")]
    public int TotalGamesPlayed { get; set; }

    [JsonPropertyName("bestScore")]
    public long BestScore { get; set; }

    [JsonPropertyName("averageScore")]
    public double AverageScore { get; set; }

    [JsonPropertyName("lastPlayedAt")]
    public DateTime LastPlayedAt { get; set; }

    [JsonPropertyName("createdAt")]
    public DateTime CreatedAt { get; set; }
}
