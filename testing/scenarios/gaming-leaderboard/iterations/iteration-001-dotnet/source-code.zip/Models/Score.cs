using System.Text.Json.Serialization;

namespace GamingLeaderboard.Models;

/// <summary>
/// Individual game score submission.
/// Container: scores, Partition Key: /playerId
/// Rule 1.6: Type discriminator
/// Rule 2.4: High cardinality partition key (playerId has ~500K values)
/// Rule 2.5: Partition key matches query pattern (get scores by player)
/// </summary>
public class Score
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = default!;

    [JsonPropertyName("playerId")]
    public string PlayerId { get; set; } = default!;

    [JsonPropertyName("type")]
    public string Type { get; set; } = "score";

    [JsonPropertyName("score")]
    public long Value { get; set; }

    [JsonPropertyName("country")]
    public string Country { get; set; } = default!;

    [JsonPropertyName("weekId")]
    public string WeekId { get; set; } = default!; // e.g., "2026-W07"

    [JsonPropertyName("submittedAt")]
    public DateTime SubmittedAt { get; set; }
}
