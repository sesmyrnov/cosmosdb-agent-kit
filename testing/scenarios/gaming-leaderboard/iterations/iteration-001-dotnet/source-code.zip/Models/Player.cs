using System.Text.Json.Serialization;

namespace GamingLeaderboard.Models;

/// <summary>
/// Player profile with cumulative stats.
/// Container: players, Partition Key: /playerId
/// Rule 1.2: Denormalize stats for read efficiency
/// Rule 1.3: Embed related data (stats are always read with player)
/// Rule 1.6: Type discriminator for polymorphic container
/// </summary>
public class Player
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = default!;

    [JsonPropertyName("playerId")]
    public string PlayerId { get; set; } = default!;

    [JsonPropertyName("type")]
    public string Type { get; set; } = "player";

    [JsonPropertyName("displayName")]
    public string DisplayName { get; set; } = default!;

    [JsonPropertyName("country")]
    public string Country { get; set; } = default!;

    [JsonPropertyName("totalGamesPlayed")]
    public int TotalGamesPlayed { get; set; }

    [JsonPropertyName("bestScore")]
    public long BestScore { get; set; }

    [JsonPropertyName("totalScore")]
    public long TotalScore { get; set; }

    [JsonPropertyName("averageScore")]
    public double AverageScore { get; set; }

    [JsonPropertyName("lastPlayedAt")]
    public DateTime LastPlayedAt { get; set; }

    [JsonPropertyName("createdAt")]
    public DateTime CreatedAt { get; set; }

    [JsonPropertyName("_etag")]
    public string? ETag { get; set; }
}
