using System.Text.Json.Serialization;

namespace GamingLeaderboard.Models;

/// <summary>
/// Leaderboard entry in the materialized view container.
/// Container: leaderboards, Partition Key: /leaderboardKey
/// 
/// Rule 9.1 (Change Feed / Materialized Views): Instead of doing expensive
/// cross-partition ORDER BY queries on scores, we maintain a denormalized
/// leaderboard container. Each entry represents a player's best score for
/// a specific leaderboard period.
/// 
/// leaderboardKey examples:
///   "global_2026-W07"     → Global weekly leaderboard
///   "US_2026-W07"         → US regional weekly leaderboard
///   "global_all-time"     → All-time global leaderboard
///   "US_all-time"         → All-time US leaderboard
/// 
/// Rule 2.2: Avoid hot partitions - weekId rotates weekly, distributing writes
/// Rule 5.1: Composite indexes on (score DESC, submittedAt ASC) for efficient 
///           leaderboard queries within a partition
/// </summary>
public class LeaderboardEntry
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = default!; // playerId (unique per player per leaderboard)

    [JsonPropertyName("leaderboardKey")]
    public string LeaderboardKey { get; set; } = default!; // Partition key

    [JsonPropertyName("type")]
    public string Type { get; set; } = "leaderboardEntry";

    [JsonPropertyName("playerId")]
    public string PlayerId { get; set; } = default!;

    [JsonPropertyName("displayName")]
    public string DisplayName { get; set; } = default!;

    [JsonPropertyName("country")]
    public string Country { get; set; } = default!;

    [JsonPropertyName("bestScore")]
    public long BestScore { get; set; }

    [JsonPropertyName("totalGamesPlayed")]
    public int TotalGamesPlayed { get; set; }

    [JsonPropertyName("lastUpdatedAt")]
    public DateTime LastUpdatedAt { get; set; }
}
