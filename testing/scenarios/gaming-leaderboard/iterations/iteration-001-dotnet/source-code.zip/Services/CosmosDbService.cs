using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Fluent;
using GamingLeaderboard.Configuration;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace GamingLeaderboard.Services;

/// <summary>
/// Initializes and provides Cosmos DB client and containers.
/// 
/// Rule 4.15: Singleton CosmosClient — registered as singleton in DI.
/// Rule 4.4: Direct connection mode for production, Gateway for emulator.
/// Rule 4.6: Emulator SSL bypass with DangerousAcceptAnyServerCertificateValidator + Gateway mode.
/// Rule 4.14: Enum serialization with CosmosSystemTextJsonSerializer + JsonStringEnumConverter.
/// Rule 4.11: Newtonsoft.Json 13.0.3+ explicitly referenced.
/// Rule 5.1: Composite indexes for ORDER BY score DESC on leaderboards container.
/// Rule 6.5: Serverless for dev/test (emulator uses serverless by default).
/// </summary>
public class CosmosDbService : IDisposable
{
    private readonly CosmosClient _client;
    private readonly CosmosDbSettings _settings;
    private readonly ILogger<CosmosDbService> _logger;

    public Container PlayersContainer { get; private set; } = default!;
    public Container ScoresContainer { get; private set; } = default!;
    public Container LeaderboardsContainer { get; private set; } = default!;

    public CosmosDbService(CosmosDbSettings settings, ILogger<CosmosDbService> logger)
    {
        _settings = settings;
        _logger = logger;

        // Rule 4.10: Log endpoint at startup to detect misconfiguration
        _logger.LogInformation("Cosmos DB Endpoint: {Endpoint}", settings.Endpoint);
        _logger.LogInformation("Cosmos DB Database: {Database}", settings.DatabaseName);
        _logger.LogInformation("Using Emulator: {UseEmulator}", settings.UseEmulator);

        // Rule 4.14: Configure System.Text.Json serializer with enum support
        var jsonSerializerOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };
        jsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());

        var clientOptions = new CosmosClientOptions
        {
            // Rule 4.6: Gateway mode for emulator (SSL issues with Direct mode)
            ConnectionMode = settings.UseEmulator ? ConnectionMode.Gateway : ConnectionMode.Direct,
            // Rule 4.14: Use System.Text.Json serializer with enum support
            UseSystemTextJsonSerializerWithOptions = jsonSerializerOptions,
            // Rule 4.6: SSL bypass for emulator
            HttpClientFactory = settings.UseEmulator
                ? () =>
                {
                    var handler = new HttpClientHandler
                    {
                        ServerCertificateCustomValidationCallback =
                            HttpClientHandler.DangerousAcceptAnyServerCertificateValidator
                    };
                    return new HttpClient(handler);
                }
                : null
        };

        _client = new CosmosClient(settings.Endpoint, settings.Key, clientOptions);
    }

    /// <summary>
    /// Initialize database and containers with proper configuration.
    /// Called at startup via IHostedService.
    /// </summary>
    public async Task InitializeAsync()
    {
        _logger.LogInformation("Initializing Cosmos DB database and containers...");

        // Create database
        var databaseResponse = await _client.CreateDatabaseIfNotExistsAsync(_settings.DatabaseName);
        var database = databaseResponse.Database;
        _logger.LogInformation("Database '{Database}' ready. Status: {Status}",
            _settings.DatabaseName, databaseResponse.StatusCode);

        // Container 1: Players (partitioned by /playerId)
        var playersProperties = new ContainerProperties
        {
            Id = _settings.PlayersContainerName,
            PartitionKeyPath = "/playerId"
        };
        var playersResponse = await database.CreateContainerIfNotExistsAsync(playersProperties);
        PlayersContainer = playersResponse.Container;
        _logger.LogInformation("Container '{Container}' ready (partition key: /playerId). RU: {RU}",
            _settings.PlayersContainerName, playersResponse.RequestCharge);

        // Container 2: Scores (partitioned by /playerId)
        // Rule 2.4: High cardinality partition key
        var scoresProperties = new ContainerProperties
        {
            Id = _settings.ScoresContainerName,
            PartitionKeyPath = "/playerId"
        };
        var scoresResponse = await database.CreateContainerIfNotExistsAsync(scoresProperties);
        ScoresContainer = scoresResponse.Container;
        _logger.LogInformation("Container '{Container}' ready (partition key: /playerId). RU: {RU}",
            _settings.ScoresContainerName, scoresResponse.RequestCharge);

        // Container 3: Leaderboards — materialized view (partitioned by /leaderboardKey)
        // Rule 9.1: Materialized view for cross-partition query optimization
        // Rule 5.1: Composite index for ORDER BY bestScore DESC
        var leaderboardProperties = new ContainerProperties
        {
            Id = _settings.LeaderboardsContainerName,
            PartitionKeyPath = "/leaderboardKey",
            IndexingPolicy = new IndexingPolicy
            {
                // Rule 5.2: Include only needed paths
                Automatic = true,
                IndexingMode = IndexingMode.Consistent,
                CompositeIndexes =
                {
                    // Rule 5.1: Composite index for leaderboard queries
                    // SELECT TOP 100 ... ORDER BY c.bestScore DESC, c.lastUpdatedAt ASC
                    new System.Collections.ObjectModel.Collection<CompositePath>
                    {
                        new CompositePath { Path = "/bestScore", Order = CompositePathSortOrder.Descending },
                        new CompositePath { Path = "/lastUpdatedAt", Order = CompositePathSortOrder.Ascending }
                    }
                }
            }
        };
        var leaderboardResponse = await database.CreateContainerIfNotExistsAsync(leaderboardProperties);
        LeaderboardsContainer = leaderboardResponse.Container;
        _logger.LogInformation("Container '{Container}' ready (partition key: /leaderboardKey). RU: {RU}",
            _settings.LeaderboardsContainerName, leaderboardResponse.RequestCharge);

        _logger.LogInformation("Cosmos DB initialization complete. All containers ready.");
    }

    public void Dispose()
    {
        _client?.Dispose();
    }
}
