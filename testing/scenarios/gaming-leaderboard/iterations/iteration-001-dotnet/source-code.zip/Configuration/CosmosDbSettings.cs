namespace GamingLeaderboard.Configuration;

/// <summary>
/// Cosmos DB configuration settings.
/// Rule 4.10: Local dev config — log endpoint at startup to detect misconfig.
/// </summary>
public class CosmosDbSettings
{
    public const string SectionName = "CosmosDb";

    public string Endpoint { get; set; } = "https://localhost:8081";
    public string Key { get; set; } = "C2y6yDjf5/R+ob0N8A7Cgv30VRDJIWEHLM+4QDU5DE2nQ9nDuVTqobD4b8mGGyPMbIZnqyMsEcaGQy67XIw/Jw==";
    public string DatabaseName { get; set; } = "gaming-leaderboard-db";
    public string PlayersContainerName { get; set; } = "players";
    public string ScoresContainerName { get; set; } = "scores";
    public string LeaderboardsContainerName { get; set; } = "leaderboards";
    public bool UseEmulator { get; set; } = true;
}
