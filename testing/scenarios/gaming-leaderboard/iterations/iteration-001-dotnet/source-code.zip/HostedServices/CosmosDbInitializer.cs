using GamingLeaderboard.Services;

namespace GamingLeaderboard.HostedServices;

/// <summary>
/// Initializes Cosmos DB database and containers at application startup.
/// </summary>
public class CosmosDbInitializer : IHostedService
{
    private readonly CosmosDbService _cosmosDbService;
    private readonly ILogger<CosmosDbInitializer> _logger;

    public CosmosDbInitializer(CosmosDbService cosmosDbService, ILogger<CosmosDbInitializer> logger)
    {
        _cosmosDbService = cosmosDbService;
        _logger = logger;
    }

    public async Task StartAsync(CancellationToken cancellationToken)
    {
        try
        {
            await _cosmosDbService.InitializeAsync();
            _logger.LogInformation("Cosmos DB initialization completed successfully.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to initialize Cosmos DB. Application may not function correctly.");
            throw;
        }
    }

    public Task StopAsync(CancellationToken cancellationToken) => Task.CompletedTask;
}
