using Microsoft.AspNetCore.Mvc;
using GamingLeaderboard.Models;
using GamingLeaderboard.Repositories;
using GamingLeaderboard.Helpers;

namespace GamingLeaderboard.Controllers;

/// <summary>
/// REST API endpoints for the gaming leaderboard system.
/// 
/// Endpoints:
///   POST /api/scores           → Submit a score
///   GET  /api/leaderboard/global?weekId=...  → Global top 100
///   GET  /api/leaderboard/regional/{country}?weekId=...  → Regional top 100
///   GET  /api/leaderboard/player/{playerId}?weekId=...   → Player rank ± 10
///   GET  /api/players/{playerId}  → Player profile with stats
/// </summary>
[ApiController]
[Route("api")]
public class LeaderboardController : ControllerBase
{
    private readonly PlayerRepository _playerRepo;
    private readonly ScoreRepository _scoreRepo;
    private readonly LeaderboardRepository _leaderboardRepo;
    private readonly ILogger<LeaderboardController> _logger;

    public LeaderboardController(
        PlayerRepository playerRepo,
        ScoreRepository scoreRepo,
        LeaderboardRepository leaderboardRepo,
        ILogger<LeaderboardController> logger)
    {
        _playerRepo = playerRepo;
        _scoreRepo = scoreRepo;
        _leaderboardRepo = leaderboardRepo;
        _logger = logger;
    }

    /// <summary>
    /// Submit a new score after completing a game.
    /// Creates/updates player profile, stores the score, and updates all relevant leaderboards.
    /// </summary>
    [HttpPost("scores")]
    public async Task<ActionResult<Score>> SubmitScore([FromBody] SubmitScoreRequest request)
    {
        if (request.Score <= 0)
            return BadRequest("Score must be positive.");

        if (string.IsNullOrWhiteSpace(request.PlayerId))
            return BadRequest("PlayerId is required.");

        var now = DateTime.UtcNow;
        var weekId = LeaderboardKeyHelper.GetWeekId(now);

        _logger.LogInformation("Submitting score {Score} for player {PlayerId} (week {WeekId})",
            request.Score, request.PlayerId, weekId);

        // Step 1: Ensure player exists (create-or-update)
        var existingPlayer = await _playerRepo.GetPlayerAsync(request.PlayerId);
        if (existingPlayer == null)
        {
            existingPlayer = new Player
            {
                Id = request.PlayerId,
                PlayerId = request.PlayerId,
                DisplayName = request.DisplayName,
                Country = request.Country,
                TotalGamesPlayed = 0,
                BestScore = 0,
                TotalScore = 0,
                AverageScore = 0,
                CreatedAt = now,
                LastPlayedAt = now
            };
            existingPlayer = await _playerRepo.UpsertPlayerAsync(existingPlayer);
        }

        // Step 2: Store the individual score
        var score = new Score
        {
            Id = Guid.NewGuid().ToString(),
            PlayerId = request.PlayerId,
            Value = request.Score,
            Country = request.Country,
            WeekId = weekId,
            SubmittedAt = now
        };
        score = await _scoreRepo.SubmitScoreAsync(score);

        // Step 3: Update player cumulative stats (denormalized — Rule 1.2)
        var updatedPlayer = await _playerRepo.UpdatePlayerStatsAsync(request.PlayerId, request.Score);

        // Step 4: Update leaderboard materialized views (Rule 9.1)
        // In production, this would be done via Change Feed processor.
        // For local dev, we update inline.
        await _leaderboardRepo.UpdateLeaderboardsAsync(updatedPlayer, request.Score, weekId);

        _logger.LogInformation("Score submitted successfully. Player {PlayerId} best: {Best}, games: {Games}",
            request.PlayerId, updatedPlayer.BestScore, updatedPlayer.TotalGamesPlayed);

        return CreatedAtAction(nameof(GetPlayerProfile), new { playerId = request.PlayerId }, score);
    }

    /// <summary>
    /// Get global top 100 leaderboard for a given week (default: current week).
    /// Single-partition query on the leaderboards materialized view.
    /// </summary>
    [HttpGet("leaderboard/global")]
    public async Task<ActionResult<LeaderboardResponse>> GetGlobalLeaderboard(
        [FromQuery] string? weekId = null,
        [FromQuery] int top = 100)
    {
        weekId ??= LeaderboardKeyHelper.GetCurrentWeekId();
        var leaderboardKey = LeaderboardKeyHelper.GlobalWeekly(weekId);

        _logger.LogInformation("Getting global leaderboard: {Key}", leaderboardKey);

        var result = await _leaderboardRepo.GetTopPlayersAsync(leaderboardKey, top);
        return Ok(result);
    }

    /// <summary>
    /// Get global all-time leaderboard (top 100).
    /// </summary>
    [HttpGet("leaderboard/global/all-time")]
    public async Task<ActionResult<LeaderboardResponse>> GetGlobalAllTimeLeaderboard(
        [FromQuery] int top = 100)
    {
        var leaderboardKey = LeaderboardKeyHelper.GlobalAllTime();

        _logger.LogInformation("Getting global all-time leaderboard: {Key}", leaderboardKey);

        var result = await _leaderboardRepo.GetTopPlayersAsync(leaderboardKey, top);
        return Ok(result);
    }

    /// <summary>
    /// Get regional top 100 leaderboard by country for a given week.
    /// </summary>
    [HttpGet("leaderboard/regional/{country}")]
    public async Task<ActionResult<LeaderboardResponse>> GetRegionalLeaderboard(
        string country,
        [FromQuery] string? weekId = null,
        [FromQuery] int top = 100)
    {
        weekId ??= LeaderboardKeyHelper.GetCurrentWeekId();
        var leaderboardKey = LeaderboardKeyHelper.RegionalWeekly(country, weekId);

        _logger.LogInformation("Getting regional leaderboard: {Key}", leaderboardKey);

        var result = await _leaderboardRepo.GetTopPlayersAsync(leaderboardKey, top);
        return Ok(result);
    }

    /// <summary>
    /// Get regional all-time leaderboard by country.
    /// </summary>
    [HttpGet("leaderboard/regional/{country}/all-time")]
    public async Task<ActionResult<LeaderboardResponse>> GetRegionalAllTimeLeaderboard(
        string country,
        [FromQuery] int top = 100)
    {
        var leaderboardKey = LeaderboardKeyHelper.RegionalAllTime(country);

        _logger.LogInformation("Getting regional all-time leaderboard: {Key}", leaderboardKey);

        var result = await _leaderboardRepo.GetTopPlayersAsync(leaderboardKey, top);
        return Ok(result);
    }

    /// <summary>
    /// Get a player's rank and the 10 players above/below them.
    /// Single-partition query on the leaderboards container.
    /// </summary>
    [HttpGet("leaderboard/player/{playerId}")]
    public async Task<ActionResult<PlayerRankResponse>> GetPlayerRank(
        string playerId,
        [FromQuery] string? weekId = null)
    {
        weekId ??= LeaderboardKeyHelper.GetCurrentWeekId();
        var leaderboardKey = LeaderboardKeyHelper.GlobalWeekly(weekId);

        _logger.LogInformation("Getting player rank for {PlayerId} in {Key}", playerId, leaderboardKey);

        var result = await _leaderboardRepo.GetPlayerRankAsync(playerId, leaderboardKey);

        if (result == null)
        {
            return NotFound(new { message = $"Player {playerId} not found in leaderboard {leaderboardKey}" });
        }

        return Ok(result);
    }

    /// <summary>
    /// Get a player's profile with cumulative stats.
    /// Point read — most efficient Cosmos DB operation.
    /// </summary>
    [HttpGet("players/{playerId}")]
    public async Task<ActionResult<PlayerProfileResponse>> GetPlayerProfile(string playerId)
    {
        _logger.LogInformation("Getting player profile for {PlayerId}", playerId);

        var player = await _playerRepo.GetPlayerAsync(playerId);

        if (player == null)
        {
            return NotFound(new { message = $"Player {playerId} not found" });
        }

        return Ok(new PlayerProfileResponse
        {
            PlayerId = player.PlayerId,
            DisplayName = player.DisplayName,
            Country = player.Country,
            TotalGamesPlayed = player.TotalGamesPlayed,
            BestScore = player.BestScore,
            AverageScore = player.AverageScore,
            LastPlayedAt = player.LastPlayedAt,
            CreatedAt = player.CreatedAt
        });
    }
}
