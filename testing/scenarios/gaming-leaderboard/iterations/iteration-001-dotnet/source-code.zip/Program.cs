using GamingLeaderboard.Configuration;
using GamingLeaderboard.HostedServices;
using GamingLeaderboard.Repositories;
using GamingLeaderboard.Services;

var builder = WebApplication.CreateBuilder(args);

// Bind Cosmos DB settings from configuration
var cosmosSettings = new CosmosDbSettings();
builder.Configuration.GetSection(CosmosDbSettings.SectionName).Bind(cosmosSettings);

// Rule 4.15: Register CosmosDbService as singleton (singleton client)
builder.Services.AddSingleton(cosmosSettings);
builder.Services.AddSingleton<CosmosDbService>();

// Register repositories
builder.Services.AddScoped<PlayerRepository>();
builder.Services.AddScoped<ScoreRepository>();
builder.Services.AddScoped<LeaderboardRepository>();

// Register hosted service for database initialization
builder.Services.AddHostedService<CosmosDbInitializer>();

// Add controllers and Swagger
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.MapControllers();

app.Run();
