package com.example.orders.config;

import com.azure.cosmos.*;
import com.azure.cosmos.models.*;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;
import java.util.Arrays;
import java.util.Collections;

/**
 * Cosmos DB config with best practices:
 * - Rule 4.1: Singleton client
 * - Rule 4.2: Async APIs
 * - Rule 4.3: Retry config
 * - Rule 4.4: Direct mode
 */
@Configuration
public class CosmosConfig {
    private static final Logger log = LoggerFactory.getLogger(CosmosConfig.class);

    @Value("${cosmos.endpoint}")
    private String endpoint;
    @Value("${cosmos.key}")
    private String key;
    @Value("${cosmos.database:ECommerceDb}")
    private String databaseName;
    @Value("${cosmos.container:Orders}")
    private String containerName;

    private CosmosAsyncClient client;

    @Bean
    public CosmosAsyncClient cosmosAsyncClient() {
        ThrottlingRetryOptions retry = new ThrottlingRetryOptions()
                .setMaxRetryAttemptsOnThrottledRequests(9)
                .setMaxRetryWaitTime(Duration.ofSeconds(30));

        this.client = new CosmosClientBuilder()
                .endpoint(endpoint)
                .key(key)
                .consistencyLevel(ConsistencyLevel.SESSION)
                .directMode()
                .throttlingRetryOptions(retry)
                .buildAsyncClient();

        // Initialize database/container
        initializeCosmosDb();

        log.info("✅ CosmosAsyncClient created (Direct mode)");
        return client;
    }

    @Bean
    public CosmosAsyncDatabase cosmosDatabase(CosmosAsyncClient c) {
        return c.getDatabase(databaseName);
    }

    @Bean
    public CosmosAsyncContainer cosmosContainer(CosmosAsyncDatabase db) {
        return db.getContainer(containerName);
    }

    private void initializeCosmosDb() {
        try {
            client.createDatabaseIfNotExists(databaseName).block();
            CosmosAsyncDatabase db = client.getDatabase(databaseName);

            IndexingPolicy idx = new IndexingPolicy();
            idx.setAutomatic(true);
            idx.setIndexingMode(IndexingMode.CONSISTENT);
            idx.setIncludedPaths(Collections.singletonList(new IncludedPath("/*")));

            CompositePath statusP = new CompositePath().setPath("/status").setOrder(CompositePathSortOrder.ASCENDING);
            CompositePath dateP = new CompositePath().setPath("/createdAt").setOrder(CompositePathSortOrder.DESCENDING);
            CompositePath custP = new CompositePath().setPath("/customerId").setOrder(CompositePathSortOrder.ASCENDING);
            idx.setCompositeIndexes(Arrays.asList(Arrays.asList(statusP, dateP), Arrays.asList(custP, dateP)));

            CosmosContainerProperties props = new CosmosContainerProperties(containerName, "/customerId");
            props.setIndexingPolicy(idx);

            db.createContainerIfNotExists(props, ThroughputProperties.createManualThroughput(400)).block();
            log.info("✅ Cosmos DB initialized: {}/{}", databaseName, containerName);
        } catch (Exception e) {
            log.error("Failed to init Cosmos DB", e);
        }
    }

    @PreDestroy
    public void cleanup() {
        if (client != null)
            client.close();
    }
}
