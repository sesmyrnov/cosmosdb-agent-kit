package com.example.orders.controller;

import com.example.orders.model.*;
import com.example.orders.model.Dtos.*;
import com.example.orders.repository.OrderRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/orders")
public class OrdersController {
    private static final Logger log = LoggerFactory.getLogger(OrdersController.class);
    private final OrderRepository repo;

    public OrdersController(OrderRepository repo) {
        this.repo = repo;
    }

    @PostMapping
    public Mono<ResponseEntity<Order>> createOrder(@RequestBody CreateOrderRequest req) {
        if (req.customerId() == null || req.customerId().isBlank())
            return Mono.just(ResponseEntity.badRequest().build());
        if (req.items() == null || req.items().isEmpty())
            return Mono.just(ResponseEntity.badRequest().build());

        Order o = new Order();
        o.setCustomerId(req.customerId());
        o.setCustomerName(req.customerName());
        o.setCustomerEmail(req.customerEmail());
        o.setItems(req.items().stream().map(i -> {
            OrderItem it = new OrderItem();
            it.setProductId(i.productId());
            it.setProductName(i.productName());
            it.setQuantity(i.quantity());
            it.setUnitPrice(i.unitPrice());
            return it;
        }).collect(Collectors.toList()));

        return repo.createOrder(o).map(c -> {
            log.info("Order created: {} for {}", c.getId(), c.getCustomerId());
            return ResponseEntity.status(HttpStatus.CREATED).body(c);
        });
    }

    @GetMapping("/{orderId}")
    public Mono<ResponseEntity<Order>> getOrder(@PathVariable String orderId, @RequestParam String customerId) {
        return repo.getOrder(orderId, customerId)
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @GetMapping("/customer/{customerId}")
    public Mono<ResponseEntity<PagedResult<Order>>> getByCustomer(
            @PathVariable String customerId,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) String continuationToken) {
        return repo.getOrdersByCustomer(customerId, pageSize, continuationToken).map(ResponseEntity::ok);
    }

    @GetMapping("/status/{status}")
    public Mono<ResponseEntity<PagedResult<OrderSummary>>> getByStatus(
            @PathVariable OrderStatus status,
            @RequestParam(defaultValue = "20") int pageSize,
            @RequestParam(required = false) String continuationToken) {
        return repo.getOrdersByStatus(status, pageSize, continuationToken).map(ResponseEntity::ok);
    }

    @GetMapping("/daterange")
    public Mono<ResponseEntity<PagedResult<OrderSummary>>> getByDateRange(
            @RequestParam Instant startDate,
            @RequestParam Instant endDate,
            @RequestParam(defaultValue = "20") int pageSize,
            @RequestParam(required = false) String continuationToken) {
        if (startDate.isAfter(endDate))
            return Mono.just(ResponseEntity.badRequest().build());
        return repo.getOrdersByDateRange(startDate, endDate, pageSize, continuationToken).map(ResponseEntity::ok);
    }

    @PatchMapping("/{orderId}/status")
    public Mono<ResponseEntity<Order>> updateStatus(
            @PathVariable String orderId,
            @RequestParam String customerId,
            @RequestBody UpdateOrderStatusRequest req) {
        return repo.updateOrderStatus(orderId, customerId, req.status())
                .map(u -> {
                    log.info("Order {} status -> {}", orderId, req.status());
                    return ResponseEntity.ok(u);
                })
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }
}
