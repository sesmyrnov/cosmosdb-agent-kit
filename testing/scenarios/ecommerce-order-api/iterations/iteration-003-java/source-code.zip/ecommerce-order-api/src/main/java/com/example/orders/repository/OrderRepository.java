package com.example.orders.repository;

import com.azure.cosmos.CosmosAsyncContainer;
import com.azure.cosmos.models.*;
import com.example.orders.model.*;
import com.example.orders.model.Dtos.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.List;

/**
 * Repository with best practices:
 * - Rule 3.1: Single-partition queries
 * - Rule 3.2: Projections
 * - Rule 3.3: Continuation tokens
 * - Rule 3.5: Parameterized queries
 * - Rule 4.10: String enum values in queries
 */
@Repository
public class OrderRepository {
    private static final Logger log = LoggerFactory.getLogger(OrderRepository.class);
    private final CosmosAsyncContainer container;

    public OrderRepository(CosmosAsyncContainer container) {
        this.container = container;
    }

    public Mono<Order> createOrder(Order order) {
        order.calculateTotals();
        order.setCreatedAt(Instant.now());
        order.setUpdatedAt(Instant.now());
        return container.createItem(order, new PartitionKey(order.getCustomerId()), new CosmosItemRequestOptions())
                .doOnSuccess(r -> log.debug("CreateOrder RU: {}", r.getRequestCharge()))
                .map(CosmosItemResponse::getItem);
    }

    public Mono<Order> getOrder(String id, String customerId) {
        return container.readItem(id, new PartitionKey(customerId), Order.class)
                .doOnSuccess(r -> log.debug("GetOrder RU: {}", r.getRequestCharge()))
                .map(CosmosItemResponse::getItem)
                .onErrorResume(e -> Mono.empty());
    }

    public Mono<PagedResult<Order>> getOrdersByCustomer(String customerId, int pageSize, String token) {
        String sql = "SELECT * FROM c WHERE c.customerId = @cid AND c.type = @type ORDER BY c.createdAt DESC";
        SqlQuerySpec q = new SqlQuerySpec(sql)
                .setParameters(List.of(new SqlParameter("@cid", customerId), new SqlParameter("@type", "order")));
        CosmosQueryRequestOptions opts = new CosmosQueryRequestOptions().setPartitionKey(new PartitionKey(customerId));

        return container.queryItems(q, opts, Order.class)
                .byPage(token, pageSize)
                .next()
                .map(p -> new PagedResult<>(p.getResults(), p.getContinuationToken(), p.getContinuationToken() != null))
                .defaultIfEmpty(new PagedResult<>(List.of(), null, false));
    }

    public Mono<PagedResult<OrderSummary>> getOrdersByStatus(OrderStatus status, int pageSize, String token) {
        // Rule 4.10: Use status.getValue() - string value!
        String sql = "SELECT c.id, c.customerId, c.customerName, c.status, c.total, ARRAY_LENGTH(c.items) as itemCount, c.createdAt FROM c WHERE c.status = @status AND c.type = @type ORDER BY c.createdAt DESC";
        SqlQuerySpec q = new SqlQuerySpec(sql)
                .setParameters(
                        List.of(new SqlParameter("@status", status.getValue()), new SqlParameter("@type", "order")));

        return container.queryItems(q, new CosmosQueryRequestOptions(), OrderSummary.class)
                .byPage(token, pageSize)
                .next()
                .map(p -> {
                    log.debug("GetOrdersByStatus RU: {} (cross-partition)", p.getRequestCharge());
                    return new PagedResult<>(p.getResults(), p.getContinuationToken(),
                            p.getContinuationToken() != null);
                })
                .defaultIfEmpty(new PagedResult<>(List.of(), null, false));
    }

    public Mono<PagedResult<OrderSummary>> getOrdersByDateRange(Instant start, Instant end, int pageSize,
            String token) {
        String sql = "SELECT c.id, c.customerId, c.customerName, c.status, c.total, ARRAY_LENGTH(c.items) as itemCount, c.createdAt FROM c WHERE c.createdAt >= @start AND c.createdAt <= @end AND c.type = @type ORDER BY c.createdAt DESC";
        SqlQuerySpec q = new SqlQuerySpec(sql)
                .setParameters(List.of(new SqlParameter("@start", start.toString()),
                        new SqlParameter("@end", end.toString()), new SqlParameter("@type", "order")));

        return container.queryItems(q, new CosmosQueryRequestOptions(), OrderSummary.class)
                .byPage(token, pageSize)
                .next()
                .map(p -> new PagedResult<>(p.getResults(), p.getContinuationToken(), p.getContinuationToken() != null))
                .defaultIfEmpty(new PagedResult<>(List.of(), null, false));
    }

    public Mono<Order> updateOrderStatus(String id, String customerId, OrderStatus newStatus) {
        CosmosPatchOperations patch = CosmosPatchOperations.create()
                .set("/status", newStatus.getValue())
                .set("/statusLower", newStatus.getValue().toLowerCase())
                .set("/updatedAt", Instant.now().toString());

        return container.patchItem(id, new PartitionKey(customerId), patch, Order.class)
                .doOnSuccess(r -> log.debug("UpdateStatus RU: {}", r.getRequestCharge()))
                .map(CosmosItemResponse::getItem)
                .onErrorResume(e -> Mono.empty());
    }
}
