package com.example.orders.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Order entity - follows Cosmos DB best practices:
 * - Rule 1.1: Embeds OrderItems (retrieved together)
 * - Rule 1.4: Denormalizes customer info for read efficiency
 * - Rule 1.5: Includes schemaVersion for evolution
 * - Rule 1.6: Uses type discriminator
 * - Rule 2.1/2.4: Uses customerId as partition key
 * - Rule 4.10: Enum serializes as STRING via @JsonValue
 */
public class Order {

    @JsonProperty("id")
    private String id = UUID.randomUUID().toString();

    @JsonProperty("customerId")
    private String customerId;

    @JsonProperty("type")
    private final String type = "order";

    @JsonProperty("schemaVersion")
    private int schemaVersion = 1;

    @JsonProperty("customerName")
    private String customerName;

    @JsonProperty("customerEmail")
    private String customerEmail;

    @JsonProperty("status")
    private OrderStatus status = OrderStatus.PENDING;

    @JsonProperty("statusLower")
    public String getStatusLower() {
        return status.getValue().toLowerCase();
    }

    @JsonProperty("items")
    private List<OrderItem> items = new ArrayList<>();

    @JsonProperty("subtotal")
    private BigDecimal subtotal = BigDecimal.ZERO;

    @JsonProperty("taxRate")
    private BigDecimal taxRate = new BigDecimal("0.08");

    @JsonProperty("taxAmount")
    private BigDecimal taxAmount = BigDecimal.ZERO;

    @JsonProperty("total")
    private BigDecimal total = BigDecimal.ZERO;

    @JsonProperty("createdAt")
    private Instant createdAt = Instant.now();

    @JsonProperty("updatedAt")
    private Instant updatedAt = Instant.now();

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getType() {
        return type;
    }

    public int getSchemaVersion() {
        return schemaVersion;
    }

    public void setSchemaVersion(int v) {
        this.schemaVersion = v;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String n) {
        this.customerName = n;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String e) {
        this.customerEmail = e;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus s) {
        this.status = s;
    }

    public List<OrderItem> getItems() {
        return items;
    }

    public void setItems(List<OrderItem> i) {
        this.items = i;
    }

    public BigDecimal getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(BigDecimal s) {
        this.subtotal = s;
    }

    public BigDecimal getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(BigDecimal t) {
        this.taxRate = t;
    }

    public BigDecimal getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(BigDecimal t) {
        this.taxAmount = t;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal t) {
        this.total = t;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant c) {
        this.createdAt = c;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant u) {
        this.updatedAt = u;
    }

    public void calculateTotals() {
        this.subtotal = items.stream()
                .map(OrderItem::getLineTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        this.taxAmount = subtotal.multiply(taxRate).setScale(2, RoundingMode.HALF_UP);
        this.total = subtotal.add(taxAmount);
    }
}
