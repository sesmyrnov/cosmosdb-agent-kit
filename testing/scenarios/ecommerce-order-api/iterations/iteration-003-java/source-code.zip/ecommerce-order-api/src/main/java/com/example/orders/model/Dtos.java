package com.example.orders.model;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

public class Dtos {
    public record CreateOrderRequest(String customerId, String customerName, String customerEmail,
            List<OrderItemRequest> items) {
    }

    public record OrderItemRequest(String productId, String productName, int quantity, BigDecimal unitPrice) {
    }

    public record UpdateOrderStatusRequest(OrderStatus status) {
    }

    public record OrderSummary(String id, String customerId, String customerName, OrderStatus status, BigDecimal total,
            int itemCount, Instant createdAt) {
    }

    public record PagedResult<T>(List<T> items, String continuationToken,
    boolean hasMore)
    {
    }
}
