using ECommerceOrderApi.Data;
using ECommerceOrderApi.Models;
using Microsoft.AspNetCore.Mvc;

namespace ECommerceOrderApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OrdersController : ControllerBase
{
    private readonly IOrderRepository _orderRepository;
    private readonly ILogger<OrdersController> _logger;

    public OrdersController(IOrderRepository orderRepository, ILogger<OrdersController> logger)
    {
        _orderRepository = orderRepository;
        _logger = logger;
    }

    /// <summary>
    /// Create a new order
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<Order>> CreateOrder([FromBody] CreateOrderRequest request)
    {
        var order = new Order
        {
            CustomerId = request.CustomerId,
            CustomerName = request.CustomerName,
            CustomerEmail = request.CustomerEmail,
            ShippingAddress = request.ShippingAddress,
            TaxRate = request.TaxRate ?? 0.08m,
            Items = request.Items.Select(i => new OrderItem
            {
                ProductId = i.ProductId,
                ProductName = i.ProductName,
                Quantity = i.Quantity,
                UnitPrice = i.UnitPrice
            }).ToList()
        };

        var createdOrder = await _orderRepository.CreateOrderAsync(order);
        
        _logger.LogInformation("Created order {OrderId} for customer {CustomerId}", 
            createdOrder.Id, createdOrder.CustomerId);

        return CreatedAtAction(
            nameof(GetOrder), 
            new { orderId = createdOrder.Id, customerId = createdOrder.CustomerId }, 
            createdOrder);
    }

    /// <summary>
    /// Get a specific order by ID
    /// Requires customerId for efficient point read (uses partition key)
    /// </summary>
    [HttpGet("{orderId}")]
    public async Task<ActionResult<Order>> GetOrder(string orderId, [FromQuery] string customerId)
    {
        if (string.IsNullOrEmpty(customerId))
        {
            return BadRequest("customerId query parameter is required for efficient lookup");
        }

        var order = await _orderRepository.GetOrderAsync(orderId, customerId);
        
        if (order == null)
        {
            return NotFound();
        }

        return Ok(order);
    }

    /// <summary>
    /// Get all orders for a specific customer
    /// Efficient single-partition query
    /// </summary>
    [HttpGet("customer/{customerId}")]
    public async Task<ActionResult<IEnumerable<Order>>> GetCustomerOrders(string customerId)
    {
        var orders = await _orderRepository.GetOrdersByCustomerAsync(customerId);
        return Ok(orders);
    }

    /// <summary>
    /// Get orders by status (Admin endpoint)
    /// Note: Cross-partition query - use with caution at scale
    /// </summary>
    [HttpGet("status/{status}")]
    public async Task<ActionResult<IEnumerable<Order>>> GetOrdersByStatus(OrderStatus status)
    {
        var orders = await _orderRepository.GetOrdersByStatusAsync(status);
        return Ok(orders);
    }

    /// <summary>
    /// Get orders within a date range (Admin endpoint)
    /// Note: Cross-partition query - use with caution at scale
    /// </summary>
    [HttpGet("daterange")]
    public async Task<ActionResult<IEnumerable<Order>>> GetOrdersByDateRange(
        [FromQuery] DateTime startDate, 
        [FromQuery] DateTime endDate)
    {
        if (startDate > endDate)
        {
            return BadRequest("startDate must be before endDate");
        }

        var orders = await _orderRepository.GetOrdersByDateRangeAsync(startDate, endDate);
        return Ok(orders);
    }

    /// <summary>
    /// Update order status
    /// Requires customerId for efficient point read/write
    /// </summary>
    [HttpPatch("{orderId}/status")]
    public async Task<ActionResult<Order>> UpdateOrderStatus(
        string orderId, 
        [FromQuery] string customerId,
        [FromBody] UpdateOrderStatusRequest request)
    {
        if (string.IsNullOrEmpty(customerId))
        {
            return BadRequest("customerId query parameter is required");
        }

        try
        {
            var updatedOrder = await _orderRepository.UpdateOrderStatusAsync(
                orderId, customerId, request.Status);
            
            _logger.LogInformation("Updated order {OrderId} status to {Status}", 
                orderId, request.Status);

            return Ok(updatedOrder);
        }
        catch (InvalidOperationException ex)
        {
            return NotFound(ex.Message);
        }
    }
}
