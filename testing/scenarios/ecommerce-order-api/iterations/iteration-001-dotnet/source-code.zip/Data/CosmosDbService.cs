using System.Collections.ObjectModel;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Options;

namespace ECommerceOrderApi.Data;

/// <summary>
/// Singleton CosmosClient factory that follows Cosmos DB best practices:
/// - Single instance per application lifetime
/// - Direct connection mode for better performance
/// - Configured preferred regions for latency optimization
/// </summary>
public class CosmosDbService : IDisposable
{
    private readonly CosmosClient _client;
    private readonly CosmosDbSettings _settings;
    private Container? _ordersContainer;

    public CosmosDbService(IOptions<CosmosDbSettings> settings)
    {
        _settings = settings.Value;

        // Best practice: Use singleton CosmosClient with Direct mode
        var clientOptions = new CosmosClientOptions
        {
            ConnectionMode = ConnectionMode.Direct,
            SerializerOptions = new CosmosSerializationOptions
            {
                PropertyNamingPolicy = CosmosPropertyNamingPolicy.CamelCase
            }
        };

        _client = new CosmosClient(_settings.Endpoint, _settings.Key, clientOptions);
    }

    /// <summary>
    /// Gets the orders container, creating database and container if they don't exist
    /// </summary>
    public async Task<Container> GetOrdersContainerAsync()
    {
        if (_ordersContainer != null)
            return _ordersContainer;

        // Create database if it doesn't exist
        var database = await _client.CreateDatabaseIfNotExistsAsync(_settings.DatabaseName);

        // Create container with customerId as partition key
        // This enables efficient queries for customer order history
        var containerProperties = new ContainerProperties(_settings.OrdersContainerName, "/customerId")
        {
            // Add composite index for common query patterns
            IndexingPolicy = new IndexingPolicy
            {
                Automatic = true,
                IndexingMode = IndexingMode.Consistent,
                IncludedPaths = { new IncludedPath { Path = "/*" } },
                CompositeIndexes =
                {
                    // Index for querying by status and date (admin queries)
                    new Collection<CompositePath>
                    {
                        new CompositePath { Path = "/status", Order = CompositePathSortOrder.Ascending },
                        new CompositePath { Path = "/orderDate", Order = CompositePathSortOrder.Descending }
                    },
                    // Index for customer order history sorted by date
                    new Collection<CompositePath>
                    {
                        new CompositePath { Path = "/customerId", Order = CompositePathSortOrder.Ascending },
                        new CompositePath { Path = "/orderDate", Order = CompositePathSortOrder.Descending }
                    }
                }
            }
        };

        var container = await database.Database.CreateContainerIfNotExistsAsync(containerProperties);
        _ordersContainer = container.Container;

        return _ordersContainer;
    }

    public void Dispose()
    {
        _client?.Dispose();
    }
}
