using ECommerceOrderApi.Models;
using Microsoft.Azure.Cosmos;

namespace ECommerceOrderApi.Data;

/// <summary>
/// Repository for Order data access operations.
/// Implements Cosmos DB best practices for efficient querying.
/// </summary>
public interface IOrderRepository
{
    Task<Order> CreateOrderAsync(Order order);
    Task<Order?> GetOrderAsync(string orderId, string customerId);
    Task<IEnumerable<Order>> GetOrdersByCustomerAsync(string customerId);
    Task<IEnumerable<Order>> GetOrdersByStatusAsync(OrderStatus status);
    Task<IEnumerable<Order>> GetOrdersByDateRangeAsync(DateTime startDate, DateTime endDate);
    Task<Order> UpdateOrderStatusAsync(string orderId, string customerId, OrderStatus newStatus);
}

public class OrderRepository : IOrderRepository
{
    private readonly CosmosDbService _cosmosDbService;

    public OrderRepository(CosmosDbService cosmosDbService)
    {
        _cosmosDbService = cosmosDbService;
    }

    public async Task<Order> CreateOrderAsync(Order order)
    {
        var container = await _cosmosDbService.GetOrdersContainerAsync();

        // Calculate totals before saving
        order.CalculateTotals();

        var response = await container.CreateItemAsync(
            order,
            new PartitionKey(order.CustomerId));

        return response.Resource;
    }

    public async Task<Order?> GetOrderAsync(string orderId, string customerId)
    {
        var container = await _cosmosDbService.GetOrdersContainerAsync();

        try
        {
            // Best practice: Point read with partition key is most efficient (1 RU)
            var response = await container.ReadItemAsync<Order>(
                orderId,
                new PartitionKey(customerId));

            return response.Resource;
        }
        catch (CosmosException ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            return null;
        }
    }

    public async Task<IEnumerable<Order>> GetOrdersByCustomerAsync(string customerId)
    {
        var container = await _cosmosDbService.GetOrdersContainerAsync();

        // Best practice: Query within a single partition is efficient
        var query = new QueryDefinition(
            "SELECT * FROM c WHERE c.customerId = @customerId ORDER BY c.orderDate DESC")
            .WithParameter("@customerId", customerId);

        var orders = new List<Order>();
        using var iterator = container.GetItemQueryIterator<Order>(
            query,
            requestOptions: new QueryRequestOptions
            {
                PartitionKey = new PartitionKey(customerId)
            });

        while (iterator.HasMoreResults)
        {
            var response = await iterator.ReadNextAsync();
            orders.AddRange(response);
        }

        return orders;
    }

    public async Task<IEnumerable<Order>> GetOrdersByStatusAsync(OrderStatus status)
    {
        var container = await _cosmosDbService.GetOrdersContainerAsync();

        // Note: This is a cross-partition query - consider using Change Feed + 
        // materialized view for high-volume admin queries in production
        var query = new QueryDefinition(
            "SELECT * FROM c WHERE c.status = @status ORDER BY c.orderDate DESC")
            .WithParameter("@status", status.ToString());

        var orders = new List<Order>();
        using var iterator = container.GetItemQueryIterator<Order>(query);

        while (iterator.HasMoreResults)
        {
            var response = await iterator.ReadNextAsync();
            orders.AddRange(response);
        }

        return orders;
    }

    public async Task<IEnumerable<Order>> GetOrdersByDateRangeAsync(DateTime startDate, DateTime endDate)
    {
        var container = await _cosmosDbService.GetOrdersContainerAsync();

        // Note: Cross-partition query - uses composite index on status/orderDate
        var query = new QueryDefinition(
            "SELECT * FROM c WHERE c.orderDate >= @startDate AND c.orderDate <= @endDate ORDER BY c.orderDate DESC")
            .WithParameter("@startDate", startDate)
            .WithParameter("@endDate", endDate);

        var orders = new List<Order>();
        using var iterator = container.GetItemQueryIterator<Order>(query);

        while (iterator.HasMoreResults)
        {
            var response = await iterator.ReadNextAsync();
            orders.AddRange(response);
        }

        return orders;
    }

    public async Task<Order> UpdateOrderStatusAsync(string orderId, string customerId, OrderStatus newStatus)
    {
        var container = await _cosmosDbService.GetOrdersContainerAsync();

        // First, read the existing order
        var existingOrder = await GetOrderAsync(orderId, customerId);
        if (existingOrder == null)
        {
            throw new InvalidOperationException($"Order {orderId} not found");
        }

        // Update status and related dates
        existingOrder.Status = newStatus;

        switch (newStatus)
        {
            case OrderStatus.Shipped:
                existingOrder.ShippedDate = DateTime.UtcNow;
                break;
            case OrderStatus.Delivered:
                existingOrder.DeliveredDate = DateTime.UtcNow;
                break;
        }

        // Replace the document
        var response = await container.ReplaceItemAsync(
            existingOrder,
            orderId,
            new PartitionKey(customerId));

        return response.Resource;
    }
}
