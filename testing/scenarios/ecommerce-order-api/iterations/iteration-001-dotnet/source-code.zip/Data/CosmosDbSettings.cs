namespace ECommerceOrderApi.Data;

/// <summary>
/// Configuration settings for Azure Cosmos DB connection
/// </summary>
public class CosmosDbSettings
{
    public const string SectionName = "CosmosDb";

    /// <summary>
    /// Cosmos DB account endpoint URL
    /// </summary>
    public string Endpoint { get; set; } = string.Empty;

    /// <summary>
    /// Cosmos DB account key (use connection string in production with Key Vault)
    /// </summary>
    public string Key { get; set; } = string.Empty;

    /// <summary>
    /// Database name
    /// </summary>
    public string DatabaseName { get; set; } = "ECommerceDb";

    /// <summary>
    /// Container name for orders
    /// </summary>
    public string OrdersContainerName { get; set; } = "Orders";
}
