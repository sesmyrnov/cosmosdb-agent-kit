using ECommerceOrderApi.Data;

var builder = WebApplication.CreateBuilder(args);

// Configure Cosmos DB settings
builder.Services.Configure<CosmosDbSettings>(
    builder.Configuration.GetSection(CosmosDbSettings.SectionName));

// Register CosmosDbService as singleton (best practice: single client instance)
builder.Services.AddSingleton<CosmosDbService>();

// Register repository
builder.Services.AddScoped<IOrderRepository, OrderRepository>();

// Add controllers
builder.Services.AddControllers();

// Add OpenAPI/Swagger
builder.Services.AddOpenApi();

var app = builder.Build();

// Add exception handling for development
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.MapOpenApi();
}

// Don't redirect to HTTPS for local testing
// app.UseHttpsRedirection();

// Map controller routes
app.MapControllers();

app.Run();

