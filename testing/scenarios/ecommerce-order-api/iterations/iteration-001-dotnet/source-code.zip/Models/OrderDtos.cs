namespace ECommerceOrderApi.Models;

/// <summary>
/// DTO for creating a new order
/// </summary>
public class CreateOrderRequest
{
    public string CustomerId { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string CustomerEmail { get; set; } = string.Empty;
    public List<CreateOrderItemRequest> Items { get; set; } = new();
    public Address? ShippingAddress { get; set; }
    public decimal? TaxRate { get; set; }
}

public class CreateOrderItemRequest
{
    public string ProductId { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public decimal UnitPrice { get; set; }
}

/// <summary>
/// DTO for updating order status
/// </summary>
public class UpdateOrderStatusRequest
{
    public OrderStatus Status { get; set; }
}

/// <summary>
/// DTO for querying orders by date range
/// </summary>
public class DateRangeQuery
{
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
}
