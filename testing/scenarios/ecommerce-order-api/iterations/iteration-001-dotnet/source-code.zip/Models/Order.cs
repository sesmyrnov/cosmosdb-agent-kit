using System.Text.Json.Serialization;

namespace ECommerceOrderApi.Models;

/// <summary>
/// Represents an order in the e-commerce system.
/// Partition key: customerId (enables efficient customer order history queries)
/// </summary>
public class Order
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = Guid.NewGuid().ToString();

    [JsonPropertyName("customerId")]
    public string CustomerId { get; set; } = string.Empty;

    [JsonPropertyName("customerName")]
    public string CustomerName { get; set; } = string.Empty;

    [JsonPropertyName("customerEmail")]
    public string CustomerEmail { get; set; } = string.Empty;

    [JsonPropertyName("status")]
    public OrderStatus Status { get; set; } = OrderStatus.Pending;

    [JsonPropertyName("orderDate")]
    public DateTime OrderDate { get; set; } = DateTime.UtcNow;

    [JsonPropertyName("shippedDate")]
    public DateTime? ShippedDate { get; set; }

    [JsonPropertyName("deliveredDate")]
    public DateTime? DeliveredDate { get; set; }

    /// <summary>
    /// Order items are embedded within the order document.
    /// This denormalization is a Cosmos DB best practice for 1:few relationships
    /// where items are always queried together with the order.
    /// </summary>
    [JsonPropertyName("items")]
    public List<OrderItem> Items { get; set; } = new();

    [JsonPropertyName("subtotal")]
    public decimal Subtotal { get; set; }

    [JsonPropertyName("taxRate")]
    public decimal TaxRate { get; set; } = 0.08m; // 8% default tax

    [JsonPropertyName("taxAmount")]
    public decimal TaxAmount { get; set; }

    [JsonPropertyName("total")]
    public decimal Total { get; set; }

    [JsonPropertyName("shippingAddress")]
    public Address? ShippingAddress { get; set; }

    /// <summary>
    /// Type discriminator for potential future document types in the same container
    /// </summary>
    [JsonPropertyName("type")]
    public string Type { get; set; } = "order";

    /// <summary>
    /// Calculates and sets the order totals based on items
    /// </summary>
    public void CalculateTotals()
    {
        Subtotal = Items.Sum(item => item.Quantity * item.UnitPrice);
        TaxAmount = Math.Round(Subtotal * TaxRate, 2);
        Total = Subtotal + TaxAmount;
    }
}

public class OrderItem
{
    [JsonPropertyName("productId")]
    public string ProductId { get; set; } = string.Empty;

    [JsonPropertyName("productName")]
    public string ProductName { get; set; } = string.Empty;

    [JsonPropertyName("quantity")]
    public int Quantity { get; set; }

    [JsonPropertyName("unitPrice")]
    public decimal UnitPrice { get; set; }

    [JsonPropertyName("lineTotal")]
    public decimal LineTotal => Quantity * UnitPrice;
}

public class Address
{
    [JsonPropertyName("street")]
    public string Street { get; set; } = string.Empty;

    [JsonPropertyName("city")]
    public string City { get; set; } = string.Empty;

    [JsonPropertyName("state")]
    public string State { get; set; } = string.Empty;

    [JsonPropertyName("zipCode")]
    public string ZipCode { get; set; } = string.Empty;

    [JsonPropertyName("country")]
    public string Country { get; set; } = "USA";
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum OrderStatus
{
    Pending,
    Shipped,
    Delivered,
    Cancelled
}
